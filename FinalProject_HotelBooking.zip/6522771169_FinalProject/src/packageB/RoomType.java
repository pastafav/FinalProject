package packageB;

public class RoomType {
	protected String room;
	
	public RoomType(String room) {
		this.room = room;
	}
	
	public String getRoomtype() {
		return room;
	}
	
		
}
	
